/**
 * @author robinvi
 * Battleship : boat package.
 */
package fr.iutvalence.theris.battleship.model.boats;