package fr.iutvalence.theris.battleship.model.boats;

/**
 * @author Robin
 * submarine.
 */
public class Submarine extends Boat {

	/**
	 * submarine constructor.
	 */
	public Submarine() {
		super(BoatSizes.SUBMARINE.getSize());
	}

}