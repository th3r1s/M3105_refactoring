package fr.iutvalence.theris.battleship.model;

/**
 * @author Robin
 * enum of the workable directions. 
 */
public enum Direction {
	
	NS,
	SN,
	EW,
	WE;

}
