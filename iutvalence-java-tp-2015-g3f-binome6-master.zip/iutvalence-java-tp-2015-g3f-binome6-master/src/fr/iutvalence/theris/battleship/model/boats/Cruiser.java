package fr.iutvalence.theris.battleship.model.boats;

/**
 * @author Robin
 * Cruiser.
 */
public class Cruiser extends Boat {

	/**
	 * cruiser constructor.
	 */
	public Cruiser() {
		super(BoatSizes.CRUISER.getSize());
	}

}
